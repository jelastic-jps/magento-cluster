# Magento 2 Acceptance Tests

The Acceptance Tests Module for **Magento_CatalogAnalytics** Module.
