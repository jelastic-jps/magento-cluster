# Magento 2 Acceptance Tests

The Acceptance Tests Module for **Magento_QuoteAnalytics** Module.